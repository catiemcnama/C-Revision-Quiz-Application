﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizApplication
{

    //TO DO
    //help screen
    //resources screen
    //finish UI
    //enter custom text for each wrong answer

    class informationGiver
    {

        public string customText;

        public void info(string currentQuestion)
        {

            if (currentQuestion.Contains("What is 7X3?")) //do this for each question
            {
                customText = "whatever";
            }
        }

    }
}
