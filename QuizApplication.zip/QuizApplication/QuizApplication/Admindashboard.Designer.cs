﻿
namespace QuizApplication
{
    partial class Admindashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admindashboard));
            this.showusersbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsAdmin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Deleteuserbtn = new System.Windows.Forms.Button();
            this.MakeAdminbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // showusersbtn
            // 
            this.showusersbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.showusersbtn.Location = new System.Drawing.Point(467, 149);
            this.showusersbtn.Margin = new System.Windows.Forms.Padding(1);
            this.showusersbtn.Name = "showusersbtn";
            this.showusersbtn.Size = new System.Drawing.Size(80, 42);
            this.showusersbtn.TabIndex = 0;
            this.showusersbtn.Text = "Show Users";
            this.showusersbtn.UseVisualStyleBackColor = true;
            this.showusersbtn.Click += new System.EventHandler(this.showusersbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Username,
            this.FirstName,
            this.LastName,
            this.Password,
            this.IsAdmin});
            this.dataGridView1.Location = new System.Drawing.Point(15, 16);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 123;
            this.dataGridView1.RowTemplate.Height = 46;
            this.dataGridView1.Size = new System.Drawing.Size(532, 125);
            this.dataGridView1.TabIndex = 1;
            // 
            // Username
            // 
            this.Username.HeaderText = "Username";
            this.Username.MinimumWidth = 15;
            this.Username.Name = "Username";
            this.Username.ReadOnly = true;
            this.Username.Width = 80;
            // 
            // FirstName
            // 
            this.FirstName.HeaderText = "First Name";
            this.FirstName.MinimumWidth = 15;
            this.FirstName.Name = "FirstName";
            this.FirstName.ReadOnly = true;
            this.FirstName.Width = 82;
            // 
            // LastName
            // 
            this.LastName.HeaderText = "Last Name";
            this.LastName.MinimumWidth = 15;
            this.LastName.Name = "LastName";
            this.LastName.ReadOnly = true;
            this.LastName.Width = 83;
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.MinimumWidth = 15;
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            this.Password.Width = 78;
            // 
            // IsAdmin
            // 
            this.IsAdmin.HeaderText = "Is Admin?";
            this.IsAdmin.MinimumWidth = 15;
            this.IsAdmin.Name = "IsAdmin";
            this.IsAdmin.ReadOnly = true;
            this.IsAdmin.Width = 78;
            // 
            // Deleteuserbtn
            // 
            this.Deleteuserbtn.Enabled = false;
            this.Deleteuserbtn.Location = new System.Drawing.Point(186, 149);
            this.Deleteuserbtn.Margin = new System.Windows.Forms.Padding(1);
            this.Deleteuserbtn.Name = "Deleteuserbtn";
            this.Deleteuserbtn.Size = new System.Drawing.Size(74, 42);
            this.Deleteuserbtn.TabIndex = 2;
            this.Deleteuserbtn.Text = "Delete Users";
            this.Deleteuserbtn.UseVisualStyleBackColor = true;
            this.Deleteuserbtn.Click += new System.EventHandler(this.Deleteuserbtn_Click);
            // 
            // MakeAdminbtn
            // 
            this.MakeAdminbtn.Enabled = false;
            this.MakeAdminbtn.Location = new System.Drawing.Point(100, 149);
            this.MakeAdminbtn.Margin = new System.Windows.Forms.Padding(1);
            this.MakeAdminbtn.Name = "MakeAdminbtn";
            this.MakeAdminbtn.Size = new System.Drawing.Size(74, 42);
            this.MakeAdminbtn.TabIndex = 3;
            this.MakeAdminbtn.Text = "Make Admin";
            this.MakeAdminbtn.UseVisualStyleBackColor = true;
            this.MakeAdminbtn.Click += new System.EventHandler(this.MakeAdminbtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 149);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 42);
            this.button1.TabIndex = 4;
            this.button1.Text = "Add User";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Admindashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(563, 255);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.MakeAdminbtn);
            this.Controls.Add(this.Deleteuserbtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.showusersbtn);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(1);
            this.MaximizeBox = false;
            this.Name = "Admindashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Dashboard - Quizapp";
            this.Load += new System.EventHandler(this.Admindashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showusersbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Deleteuserbtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsAdmin;
        private System.Windows.Forms.Button MakeAdminbtn;
        private System.Windows.Forms.Button button1;
    }
}