﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizApplication
{
    public static class UserSettings
    {
        public static string userID;
        public static int userTotal;

    }
}
