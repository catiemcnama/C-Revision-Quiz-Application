﻿
namespace QuizApplication
{
    partial class startgamescreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(startgamescreen));
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.Choosesubjectlbl = new System.Windows.Forms.Label();
            this.chooselevellbl = new System.Windows.Forms.Label();
            this.subjectcb = new System.Windows.Forms.ComboBox();
            this.levelcb = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.uScore = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.BackColor = System.Drawing.Color.White;
            this.UsernameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameLabel.Location = new System.Drawing.Point(595, 208);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(320, 72);
            this.UsernameLabel.TabIndex = 0;
            this.UsernameLabel.Text = "Username";
            this.UsernameLabel.Click += new System.EventHandler(this.UsernameLabel_Click);
            // 
            // Choosesubjectlbl
            // 
            this.Choosesubjectlbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Choosesubjectlbl.AutoSize = true;
            this.Choosesubjectlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Choosesubjectlbl.ForeColor = System.Drawing.Color.White;
            this.Choosesubjectlbl.Location = new System.Drawing.Point(177, 245);
            this.Choosesubjectlbl.Name = "Choosesubjectlbl";
            this.Choosesubjectlbl.Size = new System.Drawing.Size(409, 55);
            this.Choosesubjectlbl.TabIndex = 1;
            this.Choosesubjectlbl.Text = "Choose a subject:";
            // 
            // chooselevellbl
            // 
            this.chooselevellbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chooselevellbl.AutoSize = true;
            this.chooselevellbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooselevellbl.ForeColor = System.Drawing.Color.White;
            this.chooselevellbl.Location = new System.Drawing.Point(709, 245);
            this.chooselevellbl.Name = "chooselevellbl";
            this.chooselevellbl.Size = new System.Drawing.Size(355, 55);
            this.chooselevellbl.TabIndex = 2;
            this.chooselevellbl.Text = "Choose a level:";
            // 
            // subjectcb
            // 
            this.subjectcb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.subjectcb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subjectcb.FormattingEnabled = true;
            this.subjectcb.Items.AddRange(new object[] {
            "Maths",
            "Physics",
            "Chemistry",
            "Biology",
            "Computer Science"});
            this.subjectcb.Location = new System.Drawing.Point(155, 333);
            this.subjectcb.Name = "subjectcb";
            this.subjectcb.Size = new System.Drawing.Size(473, 63);
            this.subjectcb.TabIndex = 7;
            // 
            // levelcb
            // 
            this.levelcb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.levelcb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.levelcb.FormattingEnabled = true;
            this.levelcb.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.levelcb.Location = new System.Drawing.Point(659, 333);
            this.levelcb.Name = "levelcb";
            this.levelcb.Size = new System.Drawing.Size(451, 63);
            this.levelcb.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.Choosesubjectlbl);
            this.panel1.Controls.Add(this.levelcb);
            this.panel1.Controls.Add(this.chooselevellbl);
            this.panel1.Controls.Add(this.subjectcb);
            this.panel1.Location = new System.Drawing.Point(1080, 683);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1286, 823);
            this.panel1.TabIndex = 10;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::QuizApplication.Properties.Resources.Startbtn;
            this.pictureBox7.Location = new System.Drawing.Point(219, 498);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(830, 142);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // uScore
            // 
            this.uScore.AutoSize = true;
            this.uScore.BackColor = System.Drawing.Color.White;
            this.uScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uScore.Location = new System.Drawing.Point(1599, 148);
            this.uScore.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.uScore.Name = "uScore";
            this.uScore.Size = new System.Drawing.Size(199, 217);
            this.uScore.TabIndex = 14;
            this.uScore.Text = "0";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::QuizApplication.Properties.Resources.Logout;
            this.pictureBox6.Location = new System.Drawing.Point(611, 413);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(469, 102);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = global::QuizApplication.Properties.Resources.Help;
            this.pictureBox5.Location = new System.Drawing.Point(38, 860);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(811, 151);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::QuizApplication.Properties.Resources.resbtn;
            this.pictureBox4.Location = new System.Drawing.Point(38, 683);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(811, 159);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(63, 148);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(491, 367);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QuizApplication.Properties.Resources.userPic;
            this.pictureBox2.Location = new System.Drawing.Point(22, 83);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1124, 504);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::QuizApplication.Properties.Resources.userScore;
            this.pictureBox3.Location = new System.Drawing.Point(1270, 83);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(1124, 504);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // startgamescreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(2416, 1574);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.uScore);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.UsernameLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "startgamescreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QuizApp";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.startgamescreen_FormClosing);
            this.Load += new System.EventHandler(this.startgamescreen_Load);
            this.Shown += new System.EventHandler(this.startgamescreen_Shown);
            this.Enter += new System.EventHandler(this.startgamescreen_Enter);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.Label Choosesubjectlbl;
        private System.Windows.Forms.Label chooselevellbl;
        private System.Windows.Forms.ComboBox subjectcb;
        private System.Windows.Forms.ComboBox levelcb;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        public System.Windows.Forms.Label uScore;
    }
}